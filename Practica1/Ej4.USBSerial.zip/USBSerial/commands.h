/*
 * commands.h
 *
 *  Created on: 19 mar. 2019
 *      Author: jcgar
 */

#ifndef COMMANDS_H_
#define COMMANDS_H_


extern BaseType_t initCommandLine(uint16_t stack_size,uint8_t prioriry );


#endif /* COMMANDS_H_ */
